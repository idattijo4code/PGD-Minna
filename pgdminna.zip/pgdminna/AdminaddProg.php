<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "login")) {
  $insertSQL = sprintf("INSERT INTO program (progID, PName) VALUES (%s, %s)",
                       GetSQLValueString($_POST['Program'], "int"),
                       GetSQLValueString($_POST['name'], "text"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($insertSQL, $pgdminna) or die(mysql_error());
}
?>
<?php include('head.inc'); ?>
    <!-- //banner -->
	<div class="courses_box1">
    <a href="admin_events.php"> <<--BACK </a>
	   <div class="container">
        
   	     <form ACTION="<?php echo $editFormAction; ?>"  METHOD="POST" class="login" name="login"><?php 
					if(isset($error)){
						echo $error;
					}
			 ?>
	    	<p class="lead">Register Program</p>
            <div class="form-group">
			    <select class="required form-control" name="Program">
                      <option>-Program-</option>
                      <option value="1">MSc</option>
                      <option value="2">Ph.D</option>
                    </select>
		    </div>
		    <div class="form-group">
			    <input autocomplete="off" type="text" name="name" class="required form-control" placeholder="Enter Program Name" required>
		    </div>
		    		    <div class="form-group">
		    	
		    	<input type="submit" class="btn btn-primary btn-lg1 btn-block" value="Register Program">
		    </div>
		    		    <input type="hidden" name="MM_insert" value="login">
	        
		 </form>
	   </div>
</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
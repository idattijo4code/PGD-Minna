<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_stubio = "-1";
if (isset($_SESSION['std_Reg'])) {
  $colname_stubio = $_SESSION['std_Reg'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stubio = sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$stubio = mysql_query($query_stubio, $pgdminna) or die(mysql_error());
$row_stubio = mysql_fetch_assoc($stubio);
$totalRows_stubio = mysql_num_rows($stubio);

$sid= $row_stubio['std_ID'];


?>
<!DOCTYPE HTML>
<html>
<head>
<title>Postgraduate</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Learn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
  
 </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/jquery.countdown.css" />

<link href='//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!----Calender -------->
  <link rel="stylesheet" href="css/clndr.css" type="text/css" />
  <script src="js/underscore-min.js" type="text/javascript"></script>
  <script src= "js/moment-2.2.1.js" type="text/javascript"></script>
  <script src="js/clndr.js" type="text/javascript"></script>
  <script src="js/site.js" type="text/javascript"></script>
<!----End Calender -------->
<script type="text/javascript">
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
	        <a class="navbar-brand" href="index.php">Postgraduate</a>
	    </div>
	    <!--/.navbar-header-->
	    <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" style="height: 1px;">
	        <ul class="nav navbar-nav">
		        <li class="dropdown">
		            <a href="login.php"><i class="fa fa-user"></i><span>Admin</span></a>
		        </li>
				<li class="dropdown">
		            <a href="stlogin.php"><i class="fa fa-user"></i><span>Student</span></a>
		        </li>
		        <li class="dropdown">
		        	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list"></i><span>Courses</span></a>
		        	  <ul class="dropdown-menu">
			            
			            <li><a href="course.php">Courses List</a></li>
			            <!--<li><a href="courses.html">Courses list</a></li>
			            <li><a href="course_detail.html">Courses detail</a></li>-->
		              
		              </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-calendar"></i><span>Contact</span></a>
		             <ul class="dropdown-menu">
			            <li><a href="contact.php">Contact</a></li>
			            
		             </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-globe"></i><span>English</span></a>
		            <ul class="dropdown-menu">
			            <li><a href="#"><span><i class="flags us"></i><span>English</span></span></a></li>
			            
			        </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i><span>Search</span></a>
		            <ul class="dropdown-menu search-form">
			           <form>        
                            <input type="text" class="search-text" name="s" placeholder="Search...">    
                            <button type="submit" class="search-submit"><i class="fa fa-search"></i></button>
                       </form>
			        </ul>
		        </li>
		    </ul>
	    </div>
	    <div class="clearfix"> </div>
	  </div>
	    <!--/.navbar-collapse-->
</nav>
<nav class="navbar nav_bottom" role="navigation">
 <div class="container">
 <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header nav_2">
      <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"></a>
   </div> 
   
     </div><!-- /.navbar-collapse -->
   </div>
</nav>
<!-- banner -->
<div class="admission">
<a href="stuportal.php"> <<--BACK </a>
    	   <div class="container"> <h3 align="center"> Registered Courses</h3>
           <?php if(isset($_GET['scc'])){
	echo $_GET['scc'];
	}?>
           
           <table width="656" height="87" border="0">
  <tr>
    <td width="216"><strong>Reg. No:</strong></td>
    <td width="377"><?php echo $row_stubio['std_Reg']; ?></td>
     </tr>
  
  <tr>
    <td><strong>Choice of Course:</strong></td>
    <td><?php
					$pid = $row_stubio['program'];
					 $sql= "select * from program WHERE progID='$pid'";
						$query = mysql_query($sql, $pgdminna) or die(mysql_error());
						$row = mysql_fetch_assoc($query);
						
						echo $row['PName'];?></td>
    </tr>
</table>
        <div class="container">
	   	  
	    	    <div class="form-group">
                <form action="" method="post" name="form1" id="form1" enctype="multipart/form-data">
  <table align="center" border="0">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Semester:</td>
      <td><select name="cos_semID" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
		<option value="viewregcourses.php?sid=<?php echo $stu; ?>&sem=0">Select</option>
          <option <?php if (isset($_GET['sem']) && ($_GET['sem'])==1) {echo "SELECTED";}?> value="viewregcourses.php?sid=<?php echo $sid; ?>&sem=1">1st Sem</option>
          <option <?php if (isset($_GET['sem']) && ($_GET['sem'])==2) {echo "SELECTED";}?> value="viewregcourses.php?sid=<?php echo $sid; ?>&sem=2">2nd Sem</option>
      </select></td>
    </tr></table>
            
   <?php 
   if(isset($_GET['sem'])){
	$sem = $_GET['sem'];?>
    <table width="527" border="0" align="center">
  <tr>
    <td width="35" height="46"><strong>S/n</strong></td>
    <td width="103"><strong>Course Code</strong></td>
    <td width="249"><strong>Course Title</strong></td>
    <td width="34"><strong>Unit</strong></td>
    
  </tr>
   <?php 
   	$sess= $row_stubio['std_sessID'];
        $sqlrc = "SELECT src_regcos FROM stdregcos WHERE src_stdID = '$sid' AND src_sessID = '$sess' AND src_semID = '$sem'";
		$excrc = mysql_query($sqlrc);
		$rowsrc = mysql_fetch_assoc($excrc);
$sn = 1;	
   
   
  
 			$regcos = $rowsrc['src_regcos'];
  			$regcosarr = explode(',',$regcos);
			
  	if (isset($regcosarr) && is_array($regcosarr)){
		if (count($regcosarr) > 0){
			foreach($regcosarr as $cosid){
				
				$sqlc = "SELECT * FROM courses WHERE cos_ID = '$cosid' LIMIT 1";
				$excc = mysql_query($sqlc);
				$rowsc = mysql_fetch_assoc($excc);
			
			if($rowsc){

	?>
 
  
  <tr>
     <td><?php echo $sn ?></td>
    <td><?php echo $rowsc['cos_Code']; ?></td>
    <td><?php echo $rowsc['cos_Title']; ?></td>
    <td><?php echo $rowsc['cos_Unit']; ?></td>
    <td></td>
  </tr>
   <?php
			}
  			$sn += 1;
  			}

		}
	}}

  ?>
</table></form>


                </div>
            	   </div>
</div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
        <script type="text/javascript">
</script>
</body>
</html>
<?php
mysql_free_result($stubio);
?>

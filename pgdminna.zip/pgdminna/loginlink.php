<?php require_once('Connections/pgdminna.php'); ?>
<?php
	if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_stubio = "-1";
if (isset($_SESSION['std_Reg'])) {
  $colname_stubio = $_SESSION['std_Reg'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stubio =  sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$stubio = mysql_query($query_stubio, $pgdminna) or die(mysql_error());
$row_stubio = mysql_fetch_assoc($stubio);
$totalRows_stubio = mysql_num_rows($stubio);

$pass = $row_stubio['pwd'];

        if ($pass !='password'){
		echo "<script>window: location='stuportal.php'</script>";}
		
		else {
			echo "<script>window: location='changePW.php'</script>";}
			

mysql_free_result($stubio);
?>

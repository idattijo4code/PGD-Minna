<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "add_Topic")) {
  $insertSQL = sprintf("INSERT INTO studentbio (reaserch_topic) VALUES (%s)",
                       GetSQLValueString($_POST['researchTopic'], "text"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($insertSQL, $pgdminna) or die(mysql_error());

  $insertGoTo = "stuportal.php?";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<?php include('head.inc'); ?>
<!-- banner -->
  <div class="">
  	
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
       <?php if (isset($_GET['msg'])){
			 echo $_GET['msg']; 
			}
			?> 
	   	  <form  class="login" method="POST" action="<?php echo $editFormAction; ?>" name="add_Topic">
                <a  href="stuportal.php"> <<--Back </a> <p class="lead">Register Research Topic</p>
                <div class="form-group">
                    <input type="text" autocomplete="off" class="required form-control" placeholder="Input Research Topic *" name="researchTopic" value="">
                </div>
               
                <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-lg1 btn-block" name="submit" value="Register">
                </div>
                <input type="hidden" name="MM_insert" value="researchTopic">
                <input type="hidden" name="MM_insert" value="add_Topic">
              
            </form>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	

<?php include('head.inc'); ?>
<!-- banner -->
	<div class="banner">
			<!-- banner Slider starts Here -->
					<script src="js/responsiveslides.min.js"></script>
					 <script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider3").responsiveSlides({
							auto: true,
							pager: true,
							nav: true,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
					  </script>
					<!--//End-slider-script -->
					<div>
						
								<div class="banner-bg">
									<div class="container">
										<div class="banner-info">
											
											<a href="#"><i class="fa fa-thumbs-up icon_1" style="font-size: 20px;min-height: 0px; min-width: 0px; line-height: 20px; border-width: 0px 2px 0px 0px; margin: 0px; padding:0px 0px 0 0; letter-spacing: 0px; "></i> &nbsp;&nbsp;Welcome to the PostGraduate Portal of Federal University of technology Minna </a>
                                  
										</div>
									</div>
                                   <center> <img src="images/33.jpg" height="400"></center>
								</div>
							</li>
						</ul>
		          </div>
	</div>
	<!-- //banner -->
  
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
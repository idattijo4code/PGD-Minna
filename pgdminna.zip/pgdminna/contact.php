<?php include('head.inc'); ?>
   </div>
</nav>
<!-- banner -->
  <div class="">
  	
  </div>
    <!-- //banner -->
	<div class="features">
	   <div class="container">
	   	  <h1>How to find us</h1>
	   	  
		  <div class="wrapper">
				<div class="col_1">
					<i class="fa fa-home  icon2"></i>
					<div class="box">
						<p class="marTop9">Federal university Of,<br>Technology,Minna .</p>
					</div>
				</div>

				<div class="col_2">
					<i class="fa fa-phone  icon2"></i>
					<div class="box">
						<p class="marTop9">+234 000 000<br>+234 000 000</p>
					</div>
				</div>

				<div class="col_2">
					<i class="fa fa-envelope icon2"></i>
					<div class="box">
						<p class="m_6"><a href="" class="link4">info@pgd.edu.ng</a></p>
					</div>
				</div>
				<div class="clearfix"> </div>
		 </div>
		 <form class="contact_form">
		 	<h2>Contact form</h2>
			<div class="col-md-6 grid_6">
				<input type="text" class="text" value="Name" placeholder="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
				<input type="text" class="text" value="Email" placeholder="email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}">
				<input type="text" class="text" value="Phone" placeholder="phone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone';}">
			</div>
	
			<div class="col-md-6 grid_6">
				<textarea value="Message" placeholder="message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Message</textarea>
			</div>
            <div class="clearfix"> </div>
            <div class="btn_3">
			  <a href="#" class="more_btn" data-type="submit">Send message</a>
		    </div>
		 </form>
							
						
	  </div>
	</div>
	
	<div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
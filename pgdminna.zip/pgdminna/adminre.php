<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "reg")) {
  $insertSQL = sprintf("INSERT INTO login (`user`, pass, adminName, adminRank, adminAccess) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['user'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['admnName'], "text"),
                       GetSQLValueString($_POST['rank'], "text"),
                       GetSQLValueString($_POST['accessLvl'], "int"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($insertSQL, $pgdminna) or die(mysql_error());
}
?>
<?php include('head.inc'); ?>
<!-- banner -->
  <div class="">
  	
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
	   	  <form method="POST" action="<?php echo $editFormAction; ?>" class="login" name="reg">
               <a  href="admin_events.php"> <<--Back </a> <p class="lead">Register New Staff</p>
                <div class="form-group">
                    <input type="text" autocomplete="off" class="required form-control" placeholder="Name *" name="admnName" value="">
                </div>
               
                <div class="form-group">
                    <input type="text" value="" class="required form-control"  name="rank" placeholder="Rank">
                </div>
                <div class="form-group">
                
                    <select class="required form-control" name="accessLvl">
                      <option>-Access Level-</option>
                      <option value="1">High</option>
                      <option value="2">Medium</option>
                      <option value="3">Low</option>
                      </select>
            </div>
                                   
                 <input type="hidden" value="user" name="user">
                 <input type="hidden" value="password" name="password">
              
           
<div class="form-group">
          <input type="submit" class="btn btn-primary btn-lg1 btn-block" name="submit" value="Register">
            </div>
<input type="hidden" name="MM_insert" value="reg">
                
         </form>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_pgdminna, $pgdminna);
$query_v_ms = "SELECT * FROM studentbio";
$v_ms = mysql_query($query_v_ms, $pgdminna) or die(mysql_error());
$row_v_ms = mysql_fetch_assoc($v_ms);
$totalRows_v_ms = mysql_num_rows($v_ms);
?>
<?php include('head.inc'); ?>
<!-- banner -->
  <div class="">
  	<div class="container">
  		
  	</div>
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
	   	  <form class="login">
                <a  href="admin_events.php"> <<--Back </a><p class="lead"> MSc. Students</p>
              <table width="456" border="1">
  <tr bgcolor="#666666">
    <th scope="col">S/N</th>
    <th scope="col">REG.NO</th>
    <th scope="col">SURNAME</th>
    <th scope="col">FIRST NAME</th>
  
    </tr>
  </tr>
    <?php 
	$counter = 0;
	 $a=1 ;
 do { ?>
    
<tr <?php if ($counter++ %2) { echo 'class="color"';} ?>>
		
        
    <td height="42"><?php echo $a++; ?></td>
    <td><?php echo $row_v_ms['std_Reg'];?></td>
    <td><?php echo $row_v_ms['std_sName']; ?></td>
    <td><?php echo $row_v_ms['std_fName']; ?></td>
    
    
    </tr>
            <?php } while($row_v_ms = mysql_fetch_assoc($v_ms));?> 
             </table>

     
         </form>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>
<?php
mysql_free_result($v_ms);
?>

<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];



if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


$colname_stubio = "-1";
if (isset($_SESSION['std_Reg'])) {
  $colname_stubio = $_SESSION['std_Reg'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stubio = sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$stubio = mysql_query($query_stubio, $pgdminna) or die(mysql_error());
$row_stubio = mysql_fetch_assoc($stubio);
$totalRows_stubio = mysql_num_rows($stubio);

$image = $row_stubio['std_ID'];
$image_name =  "passports/thumbs/" . $image . ".jpg";

$pr= $row_stubio['program'];

mysql_select_db($database_pgdminna, $pgdminna);
$query_pro = "SELECT * FROM program  WHERE pID = $pr";
$pro = mysql_query($query_pro, $pgdminna) or die(mysql_error());
$row_pro = mysql_fetch_assoc($pro);
$totalRows_pro = mysql_num_rows($pro);

$p=$row_pro['progID'];
 
?>
<?php include('head.inc'); ?>
    <!-- //banner -->
    <link href="../css/style.css" rel="stylesheet" type="text/css" /><br/>
    <h2 align="center">Student Portal</h2>
	<div class="courses_box1">
	   <div class="container">
	   	  <div class="col-md-3">
			<div class="courses_box1-left">
            
              <ul>
              <li><a href="stuviewbio.php">View Bio Data</a></li>
              <?php if ($p=1){?>
               <li><a href="stuRegcourses.php">Course Registeration</a></li>
              <li><a href="viewregcourses.php">View Reg. Courses</a> </li>
              <li><a href="sturesult.php">View Result</a></li>
              <li><a href="logout.php">Research and Graduation</a></li>
              <?php }else{?>
             <li><a href="researchTopic.php">Register Research Topic</a></li>
              <?php }?>
              <li><a href="changePW.php">Change Password</a></li>
              <li><a href="logout.php">LOGOUT</a></li>
              </ul>
	       </div>
           </div>
		<div class="col-md-9">
			<div class="course_list">
                
                <ul class="table-list">
                 	 <li class="clearfix">
    				<div class="name_col"><a href=""></a></div>
                    <div class="duration_col"></div>

        				<div class="date_col"><div style="border: 1px solid #666; width: 150px; height: 150px;">
                       <img src="<?php echo $image_name;  ?>" width="150" height="150" /> </div></div>
    				</li>
    				 <li class="clearfix">
   					   <div class="name_col"><?php echo $row_stubio['std_Reg']; ?></div>
                        <div class="duration_col"></div>
                        <div class="date_col"></div>
    				</li>
    				 <li class="clearfix">
    				<div class="name_col"><?php echo $row_stubio['std_fName'].'&nbsp;'.$row_stubio['std_sName']; ?></div>
                    <div class="duration_col"></div>
                    <div class="date_col"></div>
    				</li>
   				  <li class="clearfix">
                 
   				    <div class="name_col"><?php
					$pid = $row_stubio['program'];
					 $sql= "select * from program WHERE pID='$pid'";
						$query = mysql_query($sql, $pgdminna) or die(mysql_error());
						$row = mysql_fetch_assoc($query);
						
						echo $row['PName'];?></div>
                      <div class="duration_col"></div>
                    <div class="date_col"></div>
    				</li>
    			</ul>
               </div>
		    </div>
		    <div class="clearfix"> </div>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>
<?php
mysql_free_result($pro);

mysql_free_result($stubio);
?>

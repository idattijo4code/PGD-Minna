<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "addCourse")) {
  $insertSQL = sprintf("INSERT INTO courses (cos_Code, cos_Title, cos_Unit, cos_level, cos_Sem) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['cos_Code'], "text"),
                       GetSQLValueString($_POST['cos_Title'], "text"),
                       GetSQLValueString($_POST['cos_Unit'], "int"),
                       GetSQLValueString($_POST['cos_level'], "int"),
                       GetSQLValueString($_POST['cos_Sem'], "int"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($insertSQL, $pgdminna) or die(mysql_error());

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($insertSQL, $pgdminna) or die(mysql_error());

   $msg="<h1 style='color:'red';><i>SUCCESSFULLY SUBMITTED</i></h1>";

  $insertGoTo = "add_course.php?msg=".$msg;
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<?php include('head.inc'); ?>
<!-- banner -->
  <div class="">
  	
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
	   	  <form method="POST" action="<?php echo $editFormAction; ?>" class="login" name="addCourse">
          <?php if (isset($_GET['msg'])){
			 echo $_GET['msg']; 
			}
			?> 
                <a  href="admin_events.php"> <<--Back </a><p class="lead">Register New Course</p>
                <div class="form-group">
                    <input type="text" autocomplete="off" class="required form-control" placeholder="Course Code *" name="cos_Code" value="">
                </div>
                <div class="form-group">
                    <input type="text" autocomplete="off" class="required form-control" placeholder="Course Title *" name="cos_Title" value="">
                </div>
                <div class="form-group">
                    <input type="text" autocomplete="off" class="required form-control" placeholder="Credit Unit *" name="cos_Unit" value="">
                </div>
                
                
                <div class="form-group">
                
                    <select class="required form-control" name="cos_level">
                      <option>-Program-</option>
                      <option value="1">MSc</option>
                      <option value="2">Ph.D</option>
                    </select>
                    </div>
                <div class="form-group">
                
                    <select class="required form-control" name="cos_Sem">
                      <option>-Semester-</option>
                      <option value="1">First</option>
                      <option value="2">Second</option>
                    </select>
                    </div>
                
                <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-lg1 btn-block" name="submit" value="Register">
                </div>
                <input type="hidden" name="MM_insert" value="addCourse">
                
            </form>
        
          <p>&nbsp;</p>
       </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
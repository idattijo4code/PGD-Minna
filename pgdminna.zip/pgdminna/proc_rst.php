<?php
require_once('Connections/pgdminna.php'); 

if (!isset($_SESSION)) {
  session_start();
}
//$sess = $_SESSION['sess'];
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}



if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
	$sems = $_POST['cos_Sem'];
	$cosid = $_POST['rslt_cosID'];
	$lev = $_POST['lev'];
	
	if (isset($_POST['std_Scores']) && is_array($_POST['std_Scores'])){
		if (count($_POST['std_Scores']) > 0){
						//foreach ($_POST['std_Scores'] as $key => $score){
							
						//}
			foreach ($_POST['std_Scores'] as $key => $score){
		//echo htmlspecialchars($editor, ENT_QUOTES);
		//echo '<br />';
		if($score!=''){
			if($score > 100){
				$errurl = "";
				$msg = 'Scores cannot be more than 100%';
					  header('Location: rst_entry.php?err='.$msg);
			}else{
				
		$qryt = "SELECT * FROM results WHERE rslt_semID = $sems AND rslt_cosID = $cosid AND rslt_stdID = $key";
		$exct = mysql_query($qryt)or die(mysql_error());
		$rowst = mysql_fetch_assoc($exct);
		
	if ($score>=70) {
   $gr = "A";
   $gp = 5;
	}
   elseif ($score>=60) {
   $gr = "B";
   $gp = 4;
   }
   elseif ($score>=50) {
   $gr = "C";
   $gp = 3;
   }
   elseif ($score>=45) {
   $gr = "D";
   $gp = 2;
   }
/*   elseif ($score>=40) {
   $gr = "E";
   $gp = 1;
   }
*/   elseif($score<45){
   $gr = "F";
   $gp = 0;
      }
	  if($rowst){
		 
		 // return confirm('Are you sure you want to EMPTY your cart?');
	  $sql = "UPDATE results SET rslt_scores = '$score' WHERE rslt_semID = $sems AND rslt_cosID = $cosid AND rslt_stdID = $key";
		$exc = mysql_query($sql) or die(mysql_error()) ;
		  
	  }else{

  $insertSQL = sprintf("INSERT INTO results ( rslt_semID, rslt_cosID, rslt_stdID, rslt_scores) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($sess, "int"),
                       GetSQLValueString($_POST['cos_Sem'], "int"),
                       GetSQLValueString($_POST['rslt_cosID'], "int"),
                       GetSQLValueString($key, "int"),
                       GetSQLValueString($score, "int")
					   /*GetSQLValueString($gr, "text"),
					   GetSQLValueString($gp, "int")*/);

  mysql_select_db($database_atbupgd_conn, $atbupgd_conn);
  $Result1 = mysql_query($insertSQL, $atbupgd_conn) or die(mysql_error());
				  	}//else
					
					if($gr == 'F'){
								$cqryt = "SELECT * FROM arrears WHERE arr_cosID = $cosid AND arr_stdID = $key";
							$cexct = mysql_query($cqryt)or die(mysql_error());
						$crowst = mysql_fetch_assoc($cexct);
						if(!$crowst){
							  $icqry ="INSERT INTO arrears (arr_stdID, arr_cosID, arr_sts) VALUES ($key, $cosid, 1)";
							  $icexc = mysql_query($icqry)or die(mysql_error());
						}else{
							  $ucqry ="UPDATE arrears SET arr_sts = 1 WHERE arr_stdID = $key AND arr_cosID = $cosid";
							  $ucexc = mysql_query($ucqry)or die(mysql_error());
						}
					}else{
								$cqryt = "SELECT * FROM arrears WHERE arr_cosID = $cosid AND arr_stdID = $key";
							$cexct = mysql_query($cqryt)or die(mysql_error());
						$crowst = mysql_fetch_assoc($cexct);
						if($crowst){
							  $ucqry ="UPDATE arrears SET arr_sts = 0 WHERE arr_stdID = $key AND arr_cosID = $cosid";
							  $ucexc = mysql_query($ucqry)or die(mysql_error());
						}

					}
				}/*else{
					$errurl = "rslt_entry.php?err=Scores cannot be more than 100%";
					  header(sprintf("Location: %s", $errurl ));
				}*/
			}//if
		}//foreach
  
	}//count
}else{
echo 'Required parameter missing or wrong type.';
}

  $insertGoTo = "rst_entry.php?lev=$lev&sem=$sems";
  if(isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}



?>
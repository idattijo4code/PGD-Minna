<?php include('head.inc'); ?>
      </div><!-- /.navbar-collapse -->
   </div>
</nav>
<!-- banner -->
  <div class="">
  	<div class="container">
  		
  		
        </div>
   </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
	   	  <div class="col-md-3">
			<div class="courses_box1-left">
                <form>
                 <div class="select-block1">
                    <select>
                        <option value="">Discipline</option>
                        <option value="">Discipline</option>
                        <option value="">Discipline</option>
                        <option value="">Discipline</option>
                        <option value="">Discipline</option>
                    </select>
                 </div>
                <!-- select-block -->
                 <div class="select-block1">
                    <select>
                        <option value="">Duration</option>
                        <option value="">Duration</option>
                        <option value="">Duration</option>
                        <option value="">Duration</option>
                        <option value="">Duration</option>
                    </select>
                </div>
                <!-- select-block -->
                <div class="select-block1">
                    <select>
                        <option value="">Level</option>
                        <option value="">Level</option>
                        <option value="">Level</option>
                        <option value="">Level</option>
                        <option value="">Level</option>
                    </select>
                </div>
                <!-- select-block -->
                <div class="select-block1">
                    <select>
                        <option value="">Location</option>
                        <option value="">Location</option>
                        <option value="">Location</option>
                        <option value="">Location</option>
                        <option value="">Location</option>
                    </select>
                </div>
                <!-- select-block -->
                <input type="submit" value="search" class="course-submit">		                            
            </form>
	       </div>
	       <div class="personBox">
              <div class="personBox_1">
                <div class="clearfix"> </div>
             </div>
             <div class="person_description">
                <p>&nbsp;</p>
             </div>
	       </div>
	       <ul class="posts">
	       <li>
	         <article class="entry-item">
	           <div class="clearfix"> </div>
				</article>
			</li>
			<li>
				<article class="entry-item">
				  <div class="clearfix"> </div>
				</article>
			</li>
			<li>
				<article class="entry-item">
				  <div class="clearfix"> </div>
				</article>
		    </li>
         </ul>
		</div>
		<div class="col-md-9">
        <h3>Courses</h3>
			<div class="course_list">
                <div class="table-header clearfix">
                	<div class="id_col">S/No</div>
                	<div class="name_col">Course Name</div>
                    <div class="duration_col">Duration</div>
                    
    			</div>
                <ul class="table-list">
                    <li class="clearfix">
    					<div class="id_col">1</div>

        				<div class="name_col"><a href="">PGD Computer Science</a></div>

        				<div class="duration_col">9 Months</div>
                    </li>

    				<li class="clearfix">
    					<div class="id_col">2</div>

        				<div class="name_col"><a href="">PGD. Computer Engineering</a></div>

        				<div class="duration_col">9 Months</div>
    				</li>

    				<li class="clearfix">
    					<div class="id_col">3</div>

        				<div class="name_col"><a href="">MSc. Computer Science</a></div>

        				<div class="duration_col">18 Months</div>
    				</li>

    				<li class="clearfix">
    					<div class="id_col">4</div>

        				<div class="name_col"><a href="">MSc. Computer Engineering</a></div>

        				<div class="duration_col">18 Months</div>
    				</li>

    				<li class="clearfix">
    					<div class="id_col">5</div>

        				<div class="name_col"><a href="">PhD. Computer Science</a></div>

        				<div class="duration_col">36 Months</div>
    				</li>

    				<li class="clearfix">
    					<div class="id_col">6</div>

        				<div class="name_col"><a href=""><a href="">PhD. Computer Engineering</a></div>

        				<div class="duration_col">36 Months</div>
    				</li>

    				<li class="clearfix"></li>
                </ul>
			</div>
		    </div>
		    <div class="clearfix"> </div>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
<!-- FlexSlider -->
</body>
</html>	
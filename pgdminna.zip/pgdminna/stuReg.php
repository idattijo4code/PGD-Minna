<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
$image_tempname = @$_FILES['passport']['name'];
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "stubio")) {
	
	 $image_tempname = $_FILES['passport']['name'];
			$ImageDir ="c:/xampp/htdocs/pgdminna/passports/";
			
			//**INSERT THIS LINE:
			$ImageThumb = $ImageDir . "thumbs/";
			//**END OF INSERT
			$ImageName = $ImageDir . $image_tempname;
						
			if (move_uploaded_file($_FILES['passport']['tmp_name'], $ImageName))
					{
							//get info about the image being uploaded
							list($width, $height, $type, $attr) = getimagesize($ImageName);
							
							if ($type > 3)
								{
									//echo "Sorry, but the file you uploaded was not a GIF, JPG, or PNG file.<br>";
									//echo "Please hit your browser’s ‘back’ button and try again.";
									//echo "include('error.php')";
									//header("Location: it.php");
								}else{
											//image is acceptable; ok to proceed

	
  $updateSQL = sprintf("UPDATE studentbio SET std_fName=%s, std_sName=%s, sex=%s, country=%s, email=%s, fone=%s, address=%s, title=%s WHERE std_Reg=%s",
                       GetSQLValueString($_POST['fname'], "text"),
                       GetSQLValueString($_POST['lname'], "text"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['country'], "text"),
                       GetSQLValueString($_POST['mail'], "text"),
                       GetSQLValueString($_POST['fone'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['title'], "text"),
                       GetSQLValueString($_POST['regno'], "text"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($updateSQL, $pgdminna) or die(mysql_error());

$lastpicid = mysql_insert_id();
  $newfilename = $ImageDir . $lastpicid . ".jpg";
			
					if ($type == 2){
							rename($ImageName, $newfilename);
							}
							else{
								if ($type == 1) {
									 $image_old = imagecreatefromgif($ImageName);
												}
										elseif($type == 3) {
												$image_old = imagecreatefrompng($ImageName);
														   }
												//"convert" the image to jpg
											$image_jpg = imagecreatetruecolor(300, 300/*$width, $height*/);
											imagecopyresampled($image_jpg, $image_old, 0, 0, 0, 0,300, 300, /*$width, $height*/ $width, $height);
											imagejpeg($image_jpg, $newfilename);
											imagedestroy($image_old);
											imagedestroy($image_jpg);
												}
												
												//**INSERT THESE LINES
$newthumbname = $ImageThumb . $lastpicid . ".jpg";
//get the dimensions for the thumbnail
$thumb_width = 120;
$thumb_height = 120;
//create the thumbnail
$largeimage = imagecreatefromjpeg($newfilename);
$thumb = imagecreatetruecolor($thumb_width, $thumb_height);
imagecopyresampled($thumb, $largeimage, 0, 0, 0, 0,
$thumb_width, $thumb_height, $width, $height);
imagejpeg($thumb, $newthumbname);
imagedestroy($largeimage);
imagedestroy($thumb);
//**END OF INSERT
unlink($newfilename);																}
							
						}

  $updateGoTo = "stuportal.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];

$colname_stubio = "-1";
if (isset($_SESSION['$stu'])) {
  $colname_stubio = $_SESSION['$stu'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stubio = sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$stubio = mysql_query($query_stubio, $pgdminna) or die(mysql_error());
$row_stubio = mysql_fetch_assoc($stubio);
$totalRows_stubio = mysql_num_rows($stubio);

?>
<?php include('head.inc'); ?>
<!-- banner -->
<div class="admission"><a href="stuportal.php"> <<--BACK </a>
    	   <div class="container">
           
           <table width="560" height="100" border="0">
  <tr>
    <td width="214"><h3>Reg. No:</h3></td>
    <td width="328"><?php echo $row_stubio['std_Reg']; ?></td>
     </tr>
  
  <tr>
    <td><h3>Course:</h3></td>
    <td><?php
					$pid = $row_stubio['program'];
					 $sql= "select * from program WHERE pID='$pid'";
						$query = mysql_query($sql, $pgdminna) or die(mysql_error());
						$row = mysql_fetch_assoc($query);
						
						echo $row['PName'];?></td>
    </tr>
       <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
</table>

	   	  	   	    	  <div class="col-md-6 admission_left">
	   	  	<h2>Personal Information</h2>
	   	  	<form action="<?php echo $editFormAction; ?>" name="stubio" id="stubio" enctype="multipart/form-data" method="POST" >
             <div class="select-block1">
                <select name="title" id="title">
                    <option value="">Title</option>
                    <option value="Mr.">Mr.</option>
                    <option value="Mrs.">Mrs.</option>
                    <option value="Ms.">Ms.</option>
                    <option value="Mallam">Mallam</option>
               </select>
             </div>
             <div class="input-group input-group1">
                <input value="<?php echo $row_stubio['std_fName']; ?>" class="form-control has-dark-background" name="fname" id="fname" placeholder="First Name" type="text" required>
             </div>
             <div class="input-group input-group1">
                <input value="<?php echo $row_stubio['std_sName']; ?>" class="form-control has-dark-background" name="lname" id="lname" placeholder="Last Name" type="text" required>
             </div>
            <!-- select-block -->
             
              <div class="col-md-4 form_box">
                  <div class="select-block1">
                   <select value="<?php echo $row_stubio['sex']; ?>" name="sex" id="sex">
	                    <option value="">Sex</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
	                   
                    </select>
                  </div>
              </div>
                 <div class="col-md-4 form_box">
                   <div class="select-block1">
                    
                  </div>
                 </div>
                 <div class="col-md-4 form_box1">
                   <div class="select-block1">
                    
                   </div>
              </div>
                  <div class="clearfix"> </div>
               <div class="select-block1">
                <select name="country" id="country">
                    <option value="">Country</option>
                        <option value="Nigerian">Nigerian</option>
                        <option value="Non-Nigerian">Non-Nigerian</option>
                        </select>
              </div>
              <div class="form-group col-md-12 form-group1">
                
                <div class="col-md-5">
                    
                </div>
                <div class="clearfix"> </div>
             </div>
             <div class="form-field">
			   <div class="col-md-7 photo"><label>Upload Photo <em>*</em> :&nbsp;&nbsp;&nbsp;</label></div>
			   <div class="col-md-5"><input name="passport" id="passport" type="file" class="file upload_1" onchange="AlertFilesize();"></div>
			   <div class="clearfix"> </div>
             </div>
		    <div class="form-field">
			   <div class="col-md-7 photo"><label>Upload Signature<em>*</em> :&nbsp;&nbsp;&nbsp;</label></div>
			   <div class="col-md-5"><input name="photo" id="cphoto" type="file" class="file upload_1" onchange="AlertFilesize();"></div>
			   <div class="clearfix"> </div>
             </div>
              
            </div>
            <div class="col-md-6 admission_right">
              <h3>Contact Information</h3>
              
	             <div class="input-group input-group1">
	                <input value="<?php echo $row_stubio['email']; ?>" class="form-control has-dark-background" name="mail" id="mail" placeholder="Email" type="text" required>
	             </div>
	             <div class="input-group input-group1">
	                <input value="<?php echo $row_stubio['fone']; ?>" class="form-control has-dark-background" name="fone" id="fone" placeholder="Phone no" type="text" required>
	             </div>
	             <div class="input-group input-group1">
	                <input value="<?php echo $row_stubio['address']; ?>" class="form-control has-dark-background" name="address" id="address" placeholder="Address" type="text" required>
	             </div>
	            <input type="submit" value="Register" class="course-submit">
              <input name="regno" id="regno" type="hidden" value="<?php echo $row_stubio['std_Reg']; ?>">
              <input type="hidden" name="MM_update" value="stubio">
	   	  	</form>	
	   	   </div>
	   	 			  </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>
<?php
mysql_free_result($stubio);
?>

<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_pgdminna = "localhost";
$database_pgdminna = "pgdminna";
$username_pgdminna = "root";
$password_pgdminna = "";
$pgdminna = mysql_pconnect($hostname_pgdminna, $username_pgdminna, $password_pgdminna) or trigger_error(mysql_error(),E_USER_ERROR); 
?>
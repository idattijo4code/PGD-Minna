<?php require_once('Connections/pgdminna.php'); 
function grader($score) {
   if ($score>=70) {
   $gr = "A";
   $gp = 5;
	}
   elseif ($score>=60) {
   $gr = "B";
   $gp = 4;
   }
   elseif ($score>=50) {
   $gr = "C";
   $gp = 3;
   }
   elseif ($score>=45) {
   $gr = "D";
   $gp = 2;
   }
   elseif ($score<45) {
   $gr = "F";
   $gp = 0;
      }
	return array($gr, $gp);
}
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}


	$sess =10; /*$_SESSION['sess'];*/
	$qrys = "SELECT * FROM session WHERE sess_ID = $sess";
	$excs = mysql_query($qrys);
	$rowss = mysql_fetch_assoc($excs);

/*if (isset($_GET['sem'])){
	($_GET['sem']);
}
if (isset($_GET['lev'])){
	; ($_GET['lev']);
}*/
$sem = 2;$level =1
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $rowss['sess_Name']." SESSION'S "; if($sem==1){ echo "FIRST SEMESTER";}else{ echo "SECOND SEMESTER";} echo " EXAMINATION RESULTS"; ?></title>
<style type="text/css">
.tx_align_c {
	text-align: center;
	font-weight: bold;
}

td {
	font-family: Cambria;
	font-style: normal;
	font-size:12px;
}
</style>
</head>

<body>
<a href="admin_events.php">Back</a><br />
<?php if((isset($sem) && $sem!='nil') && (isset($level) && $level!='nil')){?>
<table border="0" align="center">
  <tr>
    <td colspan="3" class="tx_align_c">FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</td>
  </tr>
  <tr>
    <td colspan="3" class="tx_align_c">POST-GRADUATE SCHOOL</td>
  </tr>
  <tr>
    <td colspan="3" class="tx_align_c"></td>
  </tr>
  <tr>
    <td class="tx_align_c"><!--SCHOOL OF ENGINEERING AND ENGINEERING TECHNOLOGY--></td>
    <td class="tx_align_c">&nbsp;</td>
    <td class="tx_align_c"><!--MECHANICAL/PRODUCTION ENGINEERING PROGRAMME--></td>
  </tr>

<tr><td align="center"></td>
  <td width="20%" align="center">&nbsp;</td>
  <td align="center"><strong><?php echo $rowss['sess_Name']." SESSION'S "; if($sem==1){ echo "FIRST SEMESTER";}else{ echo "SECOND SEMESTER";} echo " EXAMINATION RESULTS"; ?></strong></td>
</tr>
<tr><td align="center"><strong></strong></td>
  <td align="center"><strong>
    <?php /*if($level==1){ echo "PGD I";}else{ echo "PGD II";}*/ ?>
  </strong></td>
  <td align="center">&nbsp;</td>
</tr>
</table>
<?php
//$qry = "SELECT * FROM courses c, results r WHERE c.cos_ID = r.rslt_cosID AND c.cos_Sem = $sem AND r.rslt_SemID = $sem ORDER BY cos_ID";
$cqry = "SELECT * FROM courses c WHERE c.cos_Sem = $sem AND c.cos_level = $level ORDER BY cos_code";
$cexc = mysql_query($cqry)or die(mysql_error());
$crows = mysql_fetch_assoc($cexc);
$cnumrws = mysql_num_rows($cexc);

if (isset($_GET['prog'])){
	$prog= $_GET['prog'];}

	$qry = "SELECT * FROM studentbio WHERE program = $prog";
	$exc = mysql_query($qry)or die(mysql_error());
	$rows = mysql_fetch_assoc($exc);
	
	if($rows){
	
    ?>
<table width="" border="1" align="center" cellspacing="0">
 
<tr  bgcolor="#0099FF">
    <td width="28" rowspan="2" align="center">S/No.</td>
    <td width="40" rowspan="2" align="center">Reg. No.</td>
    <td width="30" rowspan="2" align="center">Name</td>
    <?php do{
    echo "<td rowspan=\"2\" align=\"center\">".$crows['cos_Code']."<br>(".$crows['cos_Unit'].")</td>";
	$cosn[] = $crows['cos_ID'];
    } while($crows = mysql_fetch_assoc($cexc));
	if($level==2){
    echo "<td rowspan=\"2\" align=\"center\">OTHERS</td>";
	}
	
	?>
    <td colspan="3" align="center">CURRENT</td>
    <td colspan="3" align="center">PREVIOUS CGPA</td>
    <td colspan="3" align="center">OVERALL</td>
    <td width="79" rowspan="2" align="center">REMARKS</td>
</tr>
<tr>
	<td width="14">SU</td>
    <td width="13">SP</td>
    <td width="21">GPA</td>
    <td width="21">CU</td>
    <td width="21">CP</td>
    <td width="35">CGPA</td>
    <td width="17">CU</td>
    <td width="17">CP</td>
    <td width="28">CGPA</td>
</tr>
    <?php 
	$sn = 1;
	do{
		$co = '';
		$fail = '';
		$cofail = '';
	$sid = $rows['std_ID'];
	
	echo "<tr bgcolor=\"#FF99FF\">";
	echo "<td>".$sn."</td>";
    echo "<td>".$rows['std_Reg']."</td>";
    echo "<td>".$rows['std_fName']." "; if($rows['std_oNames']!=''){ echo $rows['std_oNames']." ";} echo "<a href=\"sturesult2.php?sid=".($rows['std_ID'])."\"><strong>". $rows['std_sName']."</strong></a></td>";
	
	$su = '';
	$sp ='';
	$cu = '';
	$cp = '';
	$cou = '';
	$cop = '';

	if (isset($cosn) && is_array($cosn)){
		if (count($cosn) > 0){
			 foreach ($cosn as $cosid){
				$qry2 = "SELECT rslt_scores, cos_ID, cos_Code, cos_Unit FROM results r, courses c WHERE r.rslt_stdID = $sid AND r.rslt_cosID = $cosid AND r.rslt_sessID = $sess AND r.rslt_semID = $sem AND !ISNULL(r.rslt_scores) AND c.cos_ID = r.rslt_cosID AND c.cos_level = $level ORDER BY r.rslt_cosID";
	$exc2 = mysql_query($qry2)or die(mysql_error());
	$rows2 = mysql_fetch_assoc($exc2);

		if($rows2){	
	 		 $score = $rows2['rslt_scores'];
			  list($gr, $gp) = grader($score);
				echo "<td align=\"center\">".$rows2['rslt_scores'].$gr."</td>";
		$su += $rows2['cos_Unit'];
		$sp += $rows2['cos_Unit'] * $gp;
		if($gr == "F"){
			$fail .= $rows2['cos_Code'].", ";
		}
		
		}else{
			echo "<td align=\"center\"></td>";
		}

		}
			}
		}
		mysql_free_result($exc2);
	
	if($level==2){
		$oqry = "SELECT rslt_scores, cos_Code, cos_Unit FROM results r, courses c WHERE r.rslt_stdID = $sid AND r.rslt_sessID = $sess AND r.rslt_semID = $sem AND !ISNULL(r.rslt_scores) AND c.cos_ID = r.rslt_cosID AND c.cos_level = 1 ORDER BY cos_ID";
		$oexc = mysql_query($oqry)or die(mysql_error());
		$orows = mysql_fetch_assoc($oexc);
		$onumrws = mysql_num_rows($oexc);

	if($orows){
		do{
			 $score = $orows['rslt_scores'];
				 list($gr, $gp) = grader($score);
		
		$cou += $orows['cos_Unit'];
		$cop += $orows['cos_Unit'] * $gp;
		
		if($gr == "F"){
			$cofail .= $orows['cos_Code'].", ";
		}

		$co .= $orows['cos_Unit'].$orows['cos_Code']." ".$orows['rslt_scores'].$gr.", ";
		}while($orows = mysql_fetch_assoc($oexc));
	}
	   echo "<td>".$co."</td>";
	}
	?>
	<td align="center"><?php $su=$su+$cou; echo $su ?></td>
    <td align="center"><?php $sp=$sp+$cop; echo $sp ?></td>
    <td align="center"><?php if($su!=''){$num =($sp/$su);
	echo number_format($num,2);}?></td>
    <?php if($level==1 && $sem==1){?>
    <td></td>
    <td></td>
    <td></td>
    <?php }else{
		
		if($level==1 && $sem==2){
		$cqry2 = "SELECT rslt_sessID, rslt_semID, rslt_scores, cos_Unit FROM results r, courses c WHERE r.rslt_stdID = $sid AND r.rslt_cosID = c.cos_ID AND r.rslt_sessID = $sess AND rslt_semID = 1 AND c.cos_ID = r.rslt_cosID AND c.cos_level = $level ORDER BY r.rslt_cosID";
		}elseif($level==2 && $sem==1){
		$cqry2 = "SELECT rslt_sessID, rslt_semID, rslt_scores, cos_ID, cos_Code, cos_Unit FROM results r, courses c WHERE r.rslt_stdID = $sid AND r.rslt_cosID = c.cos_ID AND r.rslt_sessID < $sess AND !ISNULL(r.rslt_scores) AND c.cos_ID = r.rslt_cosID ORDER BY r.rslt_cosID";	
		}elseif($level==2 && $sem==2){
		$cqry2 = "SELECT rslt_sessID, rslt_semID, rslt_sessID, rslt_semID, rslt_scores, cos_ID, cos_Code, cos_Unit FROM results r, courses c WHERE r.rslt_stdID = $sid AND r.rslt_cosID = c.cos_ID AND r.rslt_sessID <= $sess AND !ISNULL(r.rslt_scores) AND c.cos_ID = r.rslt_cosID ORDER BY r.rslt_cosID";	
		}
	$cexc2 = mysql_query($cqry2)or die(mysql_error());
	$crows2 = mysql_fetch_assoc($cexc2);
	
	do{
		$tsess = $crows2['rslt_sessID'];
		$tsem = $crows2['rslt_semID'];
	    $score = $crows2['rslt_scores'];
	
		list($gr, $gp) = grader($score);
		
		$cu += $crows2['cos_Unit'];
		$cp += $crows2['cos_Unit'] * $gp;
	
	}while($crows2 = mysql_fetch_assoc($cexc2));
	
		?>
    <td align="center"><?php if($level==2 && $sem==2){ $cu = $cu - $su; echo $cu; }else{ echo $cu;} ?></td>
    <td align="center"><?php if($level==2 && $sem==2){ $cp = $cp - $sp; echo $cp; }else{ echo $cp;} ?></td>
    <td align="center"><?php if($cu!=''){$cnum =($cp/$cu); echo number_format($cnum,2);}?></td>
    <?php }?>
    <td align="center"><?php $cu = $cu + $su; echo $cu; ?></td>
    <td align="center"><?php $cp = $cp + $sp; echo $cp; ?></td>
    <td align="center"><?php if($cu!=''){$cnum =($cp/$cu); echo number_format($cnum,2);}?></td>
    
    <td>
    <?php
	if($su!=''){
		if($cofail!=''){
			echo "WITHDRAWN";	
		}elseif($fail !=''){
			echo "RPT: ".$fail;
		}else{
			echo "PASS";
			}
	}else{
		echo "DEFERED";	
	}
	?>
    </td>
</tr>
<?php 
	$sn +=1;

} while($rows = mysql_fetch_assoc($exc));
?>
</table>

<form action="try2.php" method="get" target="new">


<input name="lev" type="hidden" value="<?php echo $_GET['lev']; ?>" />
<input name="sem" type="hidden" value="<?php echo $_GET['sem']; ?>" />
<input type="submit" value="PRINT" /> 
</form>
<?php
	}else{
	echo "Sorry! But No any Students records were found under this category!!!";	
	}
	}else{
		echo "Sorry! But No any Programme Level and/or Semester was selected!!!";		
	}?>
</body>
</html>
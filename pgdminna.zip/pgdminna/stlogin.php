<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['log_username'])) {
  $loginUsername=$_POST['log_username'];
  $password=$_POST['log_password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "loginlink.php";
  $MM_redirectLoginFailed = "stlogin.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_pgdminna, $pgdminna);
  
  $LoginRS__query=sprintf("SELECT std_Reg, pwd FROM studentbio WHERE std_Reg=%s AND pwd=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $pgdminna) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
 
else {
	   $msg ="Invalid Registration Number or Passwaord";
    header("Location: ". $MM_redirectLoginFailed."?err=$msg" );
    
  }
}
?>
<?php include('head.inc'); ?>
    <!-- //banner -->
    <link href="../css/style.css" rel="stylesheet" type="text/css" />
    
	<div class="courses_box1">
	   <div class="container">
	   	  <form ACTION="<?php echo $loginFormAction; ?>" class="login" name="login" id="login"  enctype="multipart/form-data" method="POST">
	    	<p class="lead">LOGIN</p>
		    <div class="form-group">
			    <input autocomplete="off" type="text" name="log_username" class="required form-control" placeholder="Reg. No." required>
		    </div>
		    <div class="form-group">
			    <input autocomplete="off" type="password" class="password required form-control" placeholder="Password" name="log_password" required>
		    </div>
		    <div class="form-group" style=" color:#F00"><br/>
		    	                 <?php
  if(isset($_GET['err'])){
	echo '<div>'.$_GET['err'].'</div>';
	}
?>
		    	<input type="submit" class="btn btn-primary btn-lg1 btn-block" name="submit" value="Log In">
                 
		    </div>
	      		 </form>
               
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
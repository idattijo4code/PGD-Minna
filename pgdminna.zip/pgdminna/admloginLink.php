<?php require_once('Connections/pgdminna.php'); ?>
<?php
	if (!isset($_SESSION)) {
  session_start();
}
$id = $_SESSION['MM_Username'];

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
$user = $_GET['user'];

mysql_select_db($database_pgdminna, $pgdminna);
$query_admn = "SELECT level FROM login WHERE user ='$user'";
$admn = mysql_query($query_admn, $pgdminna) or die(mysql_error());
$row_admn = mysql_fetch_assoc($admn);
$totalRows_admn = mysql_num_rows($admn);

$level = $row_admn['level'];


switch ($level)
{
case 1:
  header("Location: admin_events.php");
  break;
case 2:
  header("Location: admin2.php");
  break;
case 3:
  header("Location: admin3.php");
  break;
default:
  header("Location: admloginLink.php");
}



/*$access = $row_admn['level'];

        if ($access ='1'){
		echo "<script>window: location='admin_events.php'</script>";}
		
		elseif ($access ='2') {
			echo "<script>window: location='admin2.php'</script>";}
			elseif ($access ='3') {
			echo "<script>window: location='admin3.php'</script>";}
*/


mysql_free_result($admn);
?>

<?php
require_once('Connections/pgdminna.php'); 
if (!isset($_SESSION)) {
  session_start();
}

//include("Connections/atbupgd_conn.php");



$editFormAction = $_SERVER['PHP_SELF'];

if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//$sess = $_SESSION['sess'];
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>

<?php include('head.inc'); ?>
<!-- banner -->
  <div class="">
  	<div class="container">
  		
  	</div>
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
      <p><center><a href="admin_events.php"> <<--Back </a></center></p>
      
	   	 <?php
if(isset($_GET['err'])){
	echo $_GET['err'];}?>
<form action="<?php echo 'proc_rst.php';//$editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
  <tr valign="baseline">
      <td nowrap="nowrap" align="right">Course Level:</td>
      <td>
      <select name="cos_lev" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
		<option value="rst_entry.php?lev=0">Select</option>
          <option <?php if (isset($_GET['lev']) && ($_GET['lev'])==1) {echo "SELECTED";}?> value="rst_entry.php?lev=1">MSc. I</option>
          <option <?php if (isset($_GET['lev']) && ($_GET['lev'])==2) {echo "SELECTED";}?> value="rst_entry.php?lev=2">MSc. II</option>
      </select>

      </td>
    </tr>
   <?php
if (isset($_GET['lev'])){
	$lev = $_GET['lev'];

?>

    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Semester:</td>
      <td>
      <select name="rslt_semID" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
		<option value="rst_entry.php?sem=0">Select</option>
          <option <?php if (isset($_GET['sem']) && ($_GET['sem'])==1) {echo "SELECTED";}?> value="rst_entry.php?lev=<?php echo $lev; ?>&sem=1">1st Sem</option>
          <option <?php if (isset($_GET['sem']) && ($_GET['sem'])==2) {echo "SELECTED";}?> value="rst_entry.php?lev=<?php echo $lev; ?>&sem=2">2nd Sem</option>
      </select>
      </td>
    </tr>
<?php

if (isset($_GET['sem'])){
	$sem = $_GET['sem'];
if (isset($_GET['lev'])){
	$lev = $_GET['lev'];
	}
mysql_select_db($database_pgdminna, $pgdminna);
$query_cos_Recset = "SELECT * FROM courses WHERE cos_Sem = '$sem' AND cos_level = '$lev' ORDER BY cos_Code";
$cos_Recset = mysql_query($query_cos_Recset, $pgdminna) or die(mysql_error());
$row_cos_Recset = mysql_fetch_assoc($cos_Recset);
$totalRows_cos_Recset = mysql_num_rows($cos_Recset);

?>
<tr valign="baseline">
      <td nowrap="nowrap" align="right">Course:</td>
      <td>
      <select name="rslt_cID" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
      <option value="rst_entry.php?lev=<?php echo $lev; ?>&sem=<?php echo $sem; ?>">Select...</option>
        <?php 
do {  
?>
        <option <?php if (isset($_GET['cid']) && ($_GET['cid'])==$row_cos_Recset['cos_ID']) {echo "SELECTED";}?> value="rst_entry.php?lev=<?php echo $lev; ?>&sem=<?php echo $sem; ?>&cid=<?php echo $row_cos_Recset['cos_ID']?>" ><?php echo $row_cos_Recset['cos_Code']?></option>
        <?php
} while ($row_cos_Recset = mysql_fetch_assoc($cos_Recset));
?>
      </select>

      </td>
    </tr>
    <?php 
	mysql_free_result($cos_Recset);
}
if(isset($_GET['cid'])){
	$cid = $_GET['cid'];
	$nmrws = '';
	$nmrws2 = '';
	?>
   <input name="cos_Sem" value="<?php echo $sem //$row_cos_Recset['cos_Sem'] ?>" type="hidden" />
  <input name="rslt_cosID" value="<?php echo $cid //$row_cos_Recset['cos_Sem'] ?>" type="hidden" />
 <input name="lev" value="<?php echo $lev //$row_cos_Recset['cos_Sem'] ?>" type="hidden" />
  </table>
  <table align="center">
    <tr style="color:#FFF" valign="baseline" bgcolor="#0033CC">
      <td nowrap="nowrap" align="center">S/No.</td>
      <td nowrap="nowrap" align="center">Reg. No.</td>
      <td nowrap="nowrap" align="center">Name</td>
      <td nowrap="nowrap" align="center">Current Level</td>
      <td nowrap="nowrap" align="center">Scores(100%)</td>
    </tr>
    <?php 

		$sql = "SELECT * FROM studentbio s, stdregcos r Where s.std_ID = r.src_stdID  AND r.src_semID = '$sem'";
		
		$query = mysql_query($sql);
	
		while($row = mysql_fetch_array($query)){
			//	$srcarr = '';
			$srcarr = explode(',',$row['src_regcos']);
			if(in_array($cid,$srcarr)){
				$sidarr[] = $row['src_stdID'];
			}

		}

		//	$srcstr = implode(',',$srcarr);
		//	echo $srcstr;

	$sn = 1;

	if (isset($sidarr) && is_array($sidarr)){
		if (count($sidarr) > 0){
			foreach ($sidarr as $sid){
				
				$sqll = "SELECT * FROM studentbio WHERE std_ID = $sid ORDER BY std_Reg";
				$query = mysql_query($sqll);
				$exc = mysql_fetch_array($query);
				
?>
    <tr style="color:#000" valign="baseline" >
      <td nowrap="nowrap" align="left"><?php echo $sn; ?></td>
      <td nowrap="nowrap" align="left"><?php echo $exc['std_Reg']; ?></td>
      <td nowrap="nowrap" align="left"><?php echo $exc['std_fName'].' '; if($exc['std_oNames']!=''){echo $exc['std_oNames'].' ';} ?> <strong><? echo $exc['std_sName']; ?></strong></td>
      <td><?php if($exc['std_clsID']==1){ echo "PGD I"; }elseif($exc['std_clsID']==2){ echo "PGD II";}  ?></td>
      <td><input type="text" name="std_Scores[<?php echo $exc['std_ID'] ?>]" value="" size="8" autofocus /></td>
    </tr>
   <?php 
}//2if
}//cidif
?>
    <?php $sn += 1;
			}
		}
	}
	?>
  </table>
  <table align="center">
    <tr valign="baseline">
      <td><input type="submit" value="Insert Scores" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>


	   </div>
       </div>
       
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>	
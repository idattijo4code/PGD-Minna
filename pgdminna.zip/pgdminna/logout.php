<?php
	session_start();
?>
<?php	
	unset($_SESSION['id']);
	unset($_SESSION['id']);
	echo "<script>window: location='index.php'</script>";
?>
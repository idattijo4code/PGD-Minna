<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_stubio = "-1";
if (isset($_SESSION['std_Reg'])) {
  $colname_stubio = $_SESSION['std_Reg'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stubio = sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$stubio = mysql_query($query_stubio, $pgdminna) or die(mysql_error());
$row_stubio = mysql_fetch_assoc($stubio);
$totalRows_stubio = mysql_num_rows($stubio);

$image = $row_stubio['std_ID'];
$image_name =  "passports/thumbs/" . $image . ".jpg";
?>
<?php include('head.inc'); ?>
<!-- banner -->
<div class="admission">
  <a href="stuportal.php"> <<--BACK </a>
    	   <div class="container"><h3 align="center">Bio Data</h3>
           <table width="555" height="100" border="0">
  <tr>
    <td width="304"><h3>Reg. No:</h3></td>
        <td width="187"><?php echo $row_stubio['std_Reg']; ?></td>
         <td width="480" rowspan="2" align="right"><div align="right" style="border: 1px solid #666; width: 150px; height: 150px;">
                       <img src="<?php echo $image_name;  ?>" width="150" height="150" align="right" /> </div></td>
        
     </tr>
  
  <tr>
    <td><h3>Course:</h3></td>
    <td><?php
					$pid = $row_stubio['program'];
					 $sql= "select * from program WHERE pID='$pid'";
						$query = mysql_query($sql, $pgdminna) or die(mysql_error());
						$row = mysql_fetch_assoc($query);
						
						echo $row['PName'];?></td>
   </tr>
</table>

	   	  	   	    	  <div class="col-md-6 admission_left">
	   	  	<div class="course_list">
                <div class="table-header clearfix">
                	<div align="center">Personal Information </div>
   			  </div>
                <ul class="table-list">
                    <li class="clearfix">
    				<div align="right">Name:</div>
                    <div class=""><?php echo $row_stubio['title'].'&nbsp'.$row_stubio['std_fName'].'&nbsp'.$row_stubio['std_sName']; ?></div>
    				</li>
                    <li class="clearfix">
    				<div align="right">Sex:</div>
                    <div class=""><?php echo $row_stubio['sex']; ?></div>
    				</li>
                    <li class="clearfix">
    				<div align="right">Country:</div>
                    <div class=""><?php echo $row_stubio['country']; ?></div>
    				</li>
              </ul>
               </div>
             </div>
            <div class="col-md-6 admission_right">
            <div class="course_list">
                <div class="table-header clearfix">
                	<div align="center">Contact Information </div>
                	
    			</div>
                <ul class="table-list">
                <li class="clearfix">
   				  <div align="right">Email:</div>
                    <div class=""><?php echo $row_stubio['email']; ?></div>
   				  </li>
                    <li class="clearfix">
    				<div align="right">Phone No:</div>
                    <div class=""><?php echo $row_stubio['fone']; ?></div>
    				</li>
                    <li class="clearfix">
    				<div align="right">Address:</div>
                    <div class=""><?php echo $row_stubio['address']; ?></div>
    				</li>
              </ul><br/>
              <div align="right"><a href="stuReg.php">Edit Bio Data</a></div>
              </div>
	            <div class="input-group input-group1">
	               

              </div>
       	  	 </form>	
	   	   </div>
	   	 			  </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
</body>
</html>
<?php
mysql_free_result($stubio);
?>

<?php require_once('Connections/pgdminna.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$stu = $_SESSION['stu'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "pw")) {
  $updateSQL = sprintf("UPDATE studentbio SET pwd=%s WHERE std_Reg=%s",
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['id'], "text"));

  mysql_select_db($database_pgdminna, $pgdminna);
  $Result1 = mysql_query($updateSQL, $pgdminna) or die(mysql_error());

  $updateGoTo = "stuReg.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_studentbio = "-1";
if (isset($_SERVER['std_Reg'])) {
  $colname_studentbio = $_SERVER['std_Reg'];
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_studentbio = sprintf("SELECT * FROM studentbio WHERE std_Reg = $stu");
$studentbio = mysql_query($query_studentbio, $pgdminna) or die(mysql_error());
$row_studentbio = mysql_fetch_assoc($studentbio);
$totalRows_studentbio = mysql_num_rows($studentbio);
 
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Postgraduate</title>
<link rel="shortcut icon" href="images/33.jpg" type="image/x-icon" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Learn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
  
 </script>
<link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>

<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/jquery.countdown.css" />

<link href='//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700' rel='stylesheet' type='text/css'>
<!----font-Awesome----->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!----font-Awesome----->
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!----Calender -------->
  <link rel="stylesheet" href="css/clndr.css" type="text/css" />
  <link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
  <link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css">
  <script src="js/underscore-min.js" type="text/javascript"></script>
  <script src= "js/moment-2.2.1.js" type="text/javascript"></script>
  <script src="js/clndr.js" type="text/javascript"></script>
  <script src="js/site.js" type="text/javascript"></script>
<!----End Calender -------->
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container">
	    <div class="navbar-header">
	        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
	        <a class="navbar-brand" href="index.php">Postgraduate</a>
	    </div>
	    <!--/.navbar-header-->
	    <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" style="height: 1px;">
	        <ul class="nav navbar-nav">
		        <li class="dropdown">
		            <a href="login.php"><i class="fa fa-user"></i><span>Admin</span></a>
		        </li>
				<li class="dropdown">
		            <a href="stlogin.php"><i class="fa fa-user"></i><span>Student</span></a>
		        </li>
		        <li class="dropdown">
		        	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-list"></i><span>Courses</span></a>
		        	  <ul class="dropdown-menu">
			            
			            <li><a href="course.php">Courses List</a></li>
			            <!--<li><a href="courses.html">Courses list</a></li>
			            <li><a href="course_detail.html">Courses detail</a></li>-->
		              
		              </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-calendar"></i><span>Contact</span></a>
		             <ul class="dropdown-menu">
			            <li><a href="contact.php">Contact</a></li>
			            
		             </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-globe"></i><span>English</span></a>
		            <ul class="dropdown-menu">
			            <li><a href="#"><span><i class="flags us"></i><span>English</span></span></a></li>
			            
			        </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i><span>Search</span></a>
		            <ul class="dropdown-menu search-form">
			           <form>        
                            <input type="text" class="search-text" name="s" placeholder="Search...">    
                            <button type="submit" class="search-submit"><i class="fa fa-search"></i></button>
                       </form>
			        </ul>
		        </li>
		    </ul>
	    </div>
	    <div class="clearfix"> </div>
	  </div>
	    <!--<!--/.navbar-collapse-->
</nav>

   </div>
</nav>
    <!-- //banner -->
    <link href="../css/style.css" rel="stylesheet" type="text/css" />
    
	<div class="courses_box1">
	   <div class="container">
       <a href="stuportal.php"> <<--BACK </a>
	   	  <form method="POST" action="<?php echo $editFormAction; ?>" class="login" name="pw" id="pw" enctype="multipart/form-data">
	    	<p class="lead">Change Password</p>
		   		    <div class="form-group"><span id="sprypassword1">
		        <input type="password"  placeholder="New Password*" name="password" id="password" class="required form-control">
	        <span class="passwordRequiredMsg">A value is required.</span></span></div>
            <div class="form-group"><span id="spryconfirm1">
              <input type="password" placeholder="Password Confirm*" name="passwordconfirm" id="passwordconfirm" class="required form-control">
            <span class="confirmRequiredMsg">A value is required.</span><span class="confirmInvalidMsg">The values don't match.</span></span></div>
		    <div class="form-group">
		    	<input type="hidden" name="id" id="id" value="<?php echo $row_studentbio['std_Reg']; ?>"/>
		    	<input type="submit" class="btn btn-primary btn-lg1 btn-block" name="submit" value="Change">
		    </div>
		    <input type="hidden" name="MM_update" value="pw">
	       
	     </form>
	   </div>
	</div>
    <div class="footer">
    	<?php include('foot.inc'); ?>
<script type="text/javascript">
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "password");
</script>
</body>
</html>
<?php
mysql_free_result($studentbio);
?>

<?php require_once('Connections/pgdminna.php'); ?>
<?php
 if (!isset($_SESSION)) {
  session_start();
}
if (isset($_GET['sid'])) {
  $stu= $_GET['sid'];}


if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
mysql_select_db($database_pgdminna, $pgdminna);
$query_stu = sprintf("SELECT * FROM studentbio WHERE std_ID = $stu");
$stu = mysql_query($query_stu, $pgdminna) or die(mysql_error());
$row_stu = mysql_fetch_assoc($stu);
$totalRows_stu = mysql_num_rows($stu);
 $sid= $row_stu['std_ID'];
 
    $sess = $row_stu['std_ID'];
	  

	$qrys = "SELECT * FROM session WHERE sess_ID = $sess";
	$excs = mysql_query($qrys);
	$rowss = mysql_fetch_assoc($excs);

$stqry = "SELECT * FROM studentbio WHERE std_ID = '$sid'";
	$stexc = mysql_query($stqry)or die(mysql_error());
	$strows = mysql_fetch_assoc($stexc);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $strows['std_Reg'].' TRANSCRIPT AS AT '.$rowss['sess_Name'].' SESSION'; ?></title>
<style type="text/css">
body,td,th {
	font-family: Cambria;
	font-size:12px;
}
a:link {
	color: #00F;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #906;
}
a:active {
	text-decoration: underline;
	color: #0F0;
}

.tx_align_c {
	text-align: center;
	font-weight: bold;
}
.tx_bold {
	font-weight: bold;

}
</style>
</head>

<body>
<a href="admin_events.php"> <<--BACK </a>
<?php
$html ='';
/*echo '<a href=std_pg.php?sid='.$sid.'>Student Page</a><br />';*/


					$pid = $strows['program'];
					 $sql= "select * from program WHERE progID='$pid'";
						$query = mysql_query($sql, $pgdminna) or die(mysql_error());
						$row = mysql_fetch_assoc($query);
						
						 ?>


<?php
$html .='	
<table align="center">
<tr>
  <td align="center" style="color:#03F">CURRENT SESSION: '.$rowss['sess_Name'].' SESSION
  </td></tr>
</table>
<table width="90%" border="0" align="center">
  <tr>
    <td class="tx_align_c">FEDERAL UNIVERSITY MINNA</td>
  </tr>
  <tr>
    <td class="tx_align_c">POST GRADUATE SCHOOL</td>
  </tr>
  <tr>
    <td class="tx_align_c"></td>
  </tr>
  <tr>
    <td class="tx_align_c">'.$row['PName'].'</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="tx_align_c"><u>TRANSCRIPT OF ACADEMIC RECORD</u></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>';

$html .='<table width=\"90%\" border=0 align=\"center\"><tr><td width=\"10%\">Name: </td><td class=\"tx_bold\">'.$strows['std_fName'].' '; if($strows['std_oNames']!=''){ $html .= $strows['std_oNames']." ";} $html .= "</td></tr><tr><td>Reg No.: </td><td  class=\"tx_bold\">".$strows['std_Reg']."</td></tr></table>";


	$sqry = "SELECT * FROM session ORDER BY sess_Name";
	$sexc = mysql_query($sqry)or die(mysql_error());
	$srows = mysql_fetch_assoc($sexc);
	do{
		$seid = $srows['sess_ID'];
		$sessarr[] = $seid; //$srows['sess_Name'];
	}while(	$srows = mysql_fetch_assoc($sexc));

//$cm = (strcmp(1, ""));
//echo $cm;

	$su = '';
	$sp ='';
	$cu = '';
	$cp = '';
	$cou = '';
	$cop = '';

	if (isset($sessarr) && is_array($sessarr)){
		if (count($sessarr) > 0){
			
			foreach ($sessarr as $value){

	$qry = "SELECT * FROM courses c, results r, session s WHERE s.sess_ID = '$value' AND r.rslt_sessID = '$value' AND r.rslt_semID = 1 AND r.rslt_cosID = c.cos_ID AND c.cos_ID = r.rslt_cosID AND r.rslt_stdID = '$sid' AND !ISNULL(r.rslt_scores) ORDER BY c.cos_code";
	$exc = mysql_query($qry)or die(mysql_error());
	$rows = mysql_fetch_assoc($exc);
	
	if($rows){
   
	$html .= "<table width=\"90%\" border=\"0\" align=\"center\"><tr><td><strong>FIRST SEMESTER ". $rows['sess_Name'] ." SESSION</strong></td></tr></table>";
$html .=
'<table width="90%" border="1" align="center" cellspacing="0">
  <tr>
    <td width="20%"><strong>COURSE CODE</strong></td>
    <td width="50%"><strong>COURSE TITLE</strong></td>
    <td width="10%" align="center"><strong>UNIT</strong></td>
    <td width="10%" align="center"><strong>MARKS</strong></td>
    <td width="10%" align="center"><strong>GRADE</strong></td>
  </tr>';
  
	
	do{
		$gr = '';
		$score = $rows['rslt_scores'];
   if ($score>=70) {
   $gr = "A";
   $gp = 5;
	}
   elseif ($score>=60) {
   $gr = "B";
   $gp = 4;
   }
   elseif ($score>=50) {
   $gr = "C";
   $gp = 3;
   }
   elseif ($score>=45) {
   $gr = "D";
   $gp = 2;
   }
/*   elseif ($score>=40){
   $gr = "E";
   $gp = 1;
   }
*/   elseif ($score<45) {
   $gr = "F";
   $gp = 0;
      }

$html .=
  '<tr>
    <td>'.$rows['cos_Code'].'</td>
    <td>'.$rows['cos_Title'].'</td>
    <td align="center">'.$rows['cos_Unit'].'</td>
    <td align="center">'.$rows['rslt_scores'].'</td>
    <td align="center">'.$gr.'</td>
  </tr>';
	
  		$su += $rows['cos_Unit'];
		$sp += $rows['cos_Unit'] * $gp;
	}while($rows = mysql_fetch_assoc($exc));

$html .=
  '<tr>
    <td align="center"><strong>SU = '.$su.'</strong></td>
    <td align="center"><strong>SP = '.$sp.'</strong></td>
    <td align="center" colspan="3"><strong>';
      if($su!=''){$num =($sp/$su);
$html .=
	"GPA = ".number_format($num,2);}
$html .=
    '</strong></td>
  </tr>
  <tr>
    <td align="center"><strong>';
       $cu+=$su; 
$html .= "CU = ".$cu;
$html .= '</strong></td>
    <td align="center"><strong>';
       $cp+=$sp;
$html .="CP = ".$cp;
$html .= '</strong></td>
    <td align="center" colspan="3"><strong>';
      if($cu!=''){$num =($cp/$cu);
$html .= "CGPA = ".number_format($num,2);}
$html .= '</strong></td>
  </tr>
 </table>';

 
$su='';
$sp='';
	}/*else{
		echo "<table width=\"90%\" border=\"0\" align=\"center\"><tr><td><strong>FIRST SEMESTER ". $rows['sess_Name'] ." SESSION</strong></td></tr><tr><td>Defered</td></tr></table>";
	}*/
	
		$qry2 = "SELECT * FROM courses c, results r, session s WHERE s.sess_ID = '$value' AND r.rslt_sessID = '$value' AND r.rslt_semID = 2 AND r.rslt_cosID = c.cos_ID AND c.cos_ID = r.rslt_cosID AND r.rslt_stdID = '$sid' AND !ISNULL(r.rslt_scores) ORDER BY c.cos_Code";
	$exc2 = mysql_query($qry2)or die(mysql_error());
	$rows2 = mysql_fetch_assoc($exc2);
	
	if($rows2){

$html .= "<table width=\"90%\" border=\"0\" align=\"center\"><tr><td><strong>SECOND SEMESTER ".$rows2['sess_Name']." SESSION</strong></td></tr></table>";

$html .=
'<table width="90%" border="1" align="center" cellspacing="0">
  <tr>
    <td width="20%"><strong>COURSE CODE</strong></td>
    <td width="50%"><strong>COURSE TITLE</strong></td>
    <td width="10%" align="center"><strong>UNIT</strong></td>
    <td width="10%" align="center"><strong>MARKS</strong></td>
    <td width="10%" align="center"><strong>GRADE</strong></td>
  </tr>';
	
	do{
		$gr = '';
		$score = $rows2['rslt_scores'];
   if ($score>=70) {
   $gr = "A";
   $gp = 5;
	}
   elseif ($score>=60) {
   $gr = "B";
   $gp = 4;
   }
   elseif ($score>=50) {
   $gr = "C";
   $gp = 3;
   }
   elseif ($score>=45) {
   $gr = "D";
   $gp = 2;
   }
/*   elseif ($score>=40){
   $gr = "E";
   $gp = 1;
   }
*/   elseif ($score<45) {
   $gr = "F";
   $gp = 0;
      }

$html .=
  '<tr>
    <td>'.$rows2['cos_Code'].'</td>
    <td>'.$rows2['cos_Title'].'</td>
    <td align="center">'.$rows2['cos_Unit'].'</td>
    <td align="center">'.$rows2['rslt_scores'].'</td>
    <td align="center">'.$gr.'</td>
  </tr>';
	
   		$su += $rows2['cos_Unit'];
		$sp += $rows2['cos_Unit'] * $gp;

	}while($rows2 = mysql_fetch_assoc($exc2));
$html .=
  '<tr>
    <td align="center"><strong>SU = '.$su.'</strong></td>
    <td align="center"><strong>SP = '.$sp.'</strong></td>
    <td align="center" colspan="3"><strong>';
    if($su!=''){$num =($sp/$su);
$html .=
	"GPA = ".number_format($num,2);}
$html .=
    '</strong></td>
  </tr>
  <tr>
    <td align="center"><strong>';
      $cu+=$su;
$html .= "CU = ".$cu;
$html .= '</strong></td>
    <td align="center"><strong>';
 $cp+=$sp;
$html .= "CP = ".$cp.'</strong></td>
    <td align="center" colspan="3"><strong>';
      if($cu!=''){$num =($cp/$cu);
$html .= "CGPA = ".number_format($num,2);}
$html .= '</strong></td>
  </tr>
 </table>';

 
$su='';
$sp='';

	}/*else{
		echo "<table width=\"90%\" border=\"0\" align=\"center\"><tr><td><strong>SECOND SEMESTER ".$rows2['sess_Name']." SESSION</strong></td></tr><tr><td>Defered</td></tr></table>";
	}*/
	
			}
echo $html;
/*include('sign.php');*/
?>
<br/><br/>
<div align="right">
<input type="submit" value="PRINT" onclick="javascript: print()" /> 
</div><br/>
<?php
		}
	}	
/*$a = "2011/2012";
$b = "2012/2013";
$r = $a-$b;
echo $r;
*/

$_SESSION['shtml'] = $html;
//$sads = '<table border="1"><tr><td>DUKKU</td>';
//$sads.= '<td> L.G. A.</td></tr></table>';
?>
</body>
</html>
<?php
mysql_free_result($stu);
?>
